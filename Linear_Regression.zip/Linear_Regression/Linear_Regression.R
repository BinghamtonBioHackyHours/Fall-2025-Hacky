# Introduction -----
# Today, we'll be analyzing a dataset of Scottish squirrel observations compiled by the Scottish Wildlife Trust and hosted on the NBN atlas. 
# This challenge set was designed by Our Coding Club, an open-source R learning tool

# Red squirrels were once dominant in the UK, but have been in sharp decline since the North American Grey Squirrel was introduced to the region. Grey squirrels are more competitive and carry the deadly squirrel pox.
# Most remaining red squirrel populations are now restricted to parts of Scotland, but are still threatened by grey squirrel expansion. 
# Red squirrels are protected species in Scotland, and are maintaining strongholds in various parts of Scotland. Organizations collect data on red and grey squirrel sightings, which we will use to analyze population trends and habitat preferences.


# First, read in the squirrel raw data, forest cover data, and squirrel metadata

# Inspect the file structure of the squirrel data. How many rows of observations are present in the raw data?
### View the metadata documentation for more detailed variable descriptions!

# Data manipulation -----
# First, we are only interested in records from the last 10 years of data collection. Keep only observations from the years 2008-2017. 

# Rename the column that holds the year of observations (Start.date.year) to 'Year'

# Next, remove observations that are not at the species level (those that don't tell us whether they are red or grey squirrels)

# Create a new 'Species' column that has Red Squirrel and Grey Squirrel as factor levels

# We will assume that observations that have NA as 'Individual.count' are observations of 1 squirrel. Replace them with the value 1.

# Re-inspect your data structure. 
# Do you have 'Year', 'Species', and 'Individual.count' columns? Are their data types appropriate intuitively? 
# How many rows are in your cleaned dataset?

# Temporal trends -----
# Next, we'll look to see if there are temporal trends in the number of observations for red and grey squirrels from 2008-2017. 

# Summarize the number of observations per species per year. 


# Run a linear model to answer the question: Have squirrel populations increased or decreased over time, and is the trend the same for red and grey squirrels?
# Interpret the summary of the linear model
# Plot the data with trendlines

# Which species showed the strongest change over time?
# What were your predictor variable(s), and their data type in the model?
# What is the adjusted R-squared of the regression?
# Considering the nature of our response variable, what modeling approach might be more appropriate?
# What could be driving these trends? Are they ecologically meaningful? Any data biases?


# Habitat preference spatial anlaysis -----
# Based on anecdotal evidence, we hypothesize that grey squirrels are city dwellers, while red squirrels reside in forests. 
# In this section, we will determine whether recent squirrel counts in OS grid cells (10km resolution) are linked to forest cover in the cell. 

# Filter the data to the time period from 2015-2017. 

# Summarize squirrel count data at the species and grid cell level. 

# Remove observations >300 (They mess with plots later, but feel free to experiment with different subsets!)

# Merge your grid-level summary count with forest cover dataset
# Convert the forest cover column from proportions to percentages

# Visualize the scatterplot of abundance as a function of forest cover for each species 
# Run a linear model to test the relationship. 


# Are red squirrels significantly associated with forested areas?
# Does the model explain the variation in the data well?

# BONUS: try running a GLM with the appropriate distribution!

# Forest cover preferences -----
# First we'll reclassify forest cover from a continuous variable to a categorical variable. 
# Transform forest cover data into a cover.class variable with bins for: 0-10%, 10-20%, 20-30%, 30-40%, 40-50%, and 50+%.

# Visualize the data to display the mean abundance of grey and red squirrels in these classes, and the uncertainty around these measures. (bar plot alert!)

# In what cover classes are red squirrels more abundant than grey?