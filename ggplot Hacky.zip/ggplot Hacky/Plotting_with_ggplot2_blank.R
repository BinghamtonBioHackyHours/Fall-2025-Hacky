#This intro to plotting with ggplo2 is based on the tutorial from Our Coding Club. Here are the links to both of their tutorials if you want to take a closer look: 
#https://ourcodingclub.github.io/tutorials/datavis/
#https://ourcodingclub.github.io/tutorials/data-vis-2/


# Getting Started ---------------------------------------------------------

#Load in your libaries
library(ggplot2)
library(dplyr)
library(tidyr)

#check that you are in the correct working directory:

#set the path to the correct working directory if you need to:

#read in the data:


#check the structure of the data


# land - the location within the land of magic (two possible lands: Narnia and Hogsmeade)
# plot - the plot number within each land
# year - the year the measurement was taken
# species - the species name (or code), Note that these are fake species!
# height - the imaginary canopy height at that point
# id - the id of each observation

# Making a Histogram ------------------------------------------------------

#Let's start by making a histogram in base R. 
#It won't bee super informative, but let's take a look at a histogram of magic plant height.


#let's do the same thing with ggplot:
# With ggplot2: creating graph with no brackets

#This is kind of ugly.... What can we add to make this better?


##Taking a look at some of the jargon -------------

#geom: a geometric object that lets you define what graph you want. You give it your data with the aesthetics mapping to tell it what variables you want to use.
##Common examples: geom_point(), geom_boxplot(), geom_histogram(), geom_col()

#aes: "Aesthetics". Generally appears inside a geom_. This is where we tell ggplot what data/variables we are working with. It also lets us change the 'properties' of the graph. Ex) If you want your data points to be colored based on a factor (e.g. by sex), you'll specify 'color = '  inside  aes().

#stat: This allows us to transform the data statistically.
## Ex) stat_smooth(method = 'lm') gives us a linear regression line and confidence interval ribbon on top of a scatter plot

#theme: Theme basically controls the aesthetics of the graph. For example, it controls the background, borders, text size, legend position, axes, etc. 
##When working inside a theme, you can alter the elements you don't like. These include axis.text, legend.title, and so on. You can do this with: elements_...() functions

# Another Look at Histograms ----------------------------------------------

#To make a more informative histogram, let's start with a challenge:
#Calculate how many species are in each plot


#Now, use ggplot2 to generate a histogram to visualize how many species are in each plot based on the land they were sampled from.



#installing ThemePark to have some fun with plot themes
# install.packages("remotes")
# remotes::install_github("MatthewBJane/ThemePark")
# library(ThemePark)

# Boxplots in R -----------------------------------------------------------

#Box plots show the median and spread of your data, and allow you to quickly compare values among groups. Let's use a boxplot to visualize which plots are most species-rich.

#An example that doesn't tell us a whole lot!
ggplot(species_counts, aes(plot, Species_number, fill = land)) +
  geom_boxplot()

#What if we create a dataset where we tell R we want to account for year? Try it! Modify the species_counts code you used above to include a column for year.


#try plotting with yearly_counts this time


##Challenge: Use your new ggplot knowledge to spruce up this plot. Change the colors to indicate different lands, move the legend to the bottom, give the axes cleaner titles, and give the plot a name. 

# Scatterplots ------------------------------------------------------------

#scatterplots show relationships between continuous variables

#Challenge: Let's take a look at plant heights and how they've changed over time. Manipulate the data to pull out the heights. (Hint: you'll want to group them by year, land, plot, and id). We'll also want to calculate the mean max height


#use ggplot to make a simple scatterplot to see waht we are working with


#we can see some trends in the data. Let's add a straight trendline!


#The relationship doesn't seem to be linear. Let's try using a quadratic fit. We can do this using the "formula =" argument 


#Let's play around with more scatterplots
#We'll read in a new dataset for this one:


##check the structure of the data frame - does anything look like it needs to be changed?


#This is a really large dataset - let's pick just one species to focus on. Let's start by looking at all of our unique species


#Challenge: manipulate the dataset to focus on our species of interest


#check the structure of the data frame - does anything look like it needs to be changed?


# There are a lot of NAs in this dataframe, so we will get rid of the empty rows 


# Let's narrow it down to two countries to start. Filter the data to get records only from Croatia and Italy 


#Plot this in base R


#Challenge: use your ggplot skills to make a scatterplot with custom colors for the different countries, labels on the axes, and a legend


#Now, let's add a linear model fit that is color-coded by country


# What if we want to examine the change in populations of vultures across other countries? If we put them all on the same graph, it'll be really cluttered! Let's add a faceting layer to to split the data into multiple panels

